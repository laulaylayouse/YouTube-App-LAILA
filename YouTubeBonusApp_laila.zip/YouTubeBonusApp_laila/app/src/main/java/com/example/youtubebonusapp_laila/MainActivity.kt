package com.example.youtubebonusapp_laila

import android.content.Context
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var YouTube_Player_View: YouTubePlayerView
    lateinit var YouTube_Player: YouTubePlayer
    lateinit var Grid_View: GridView

    private var current = 0
    private var time = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title ="YouTube Bonus App "

        val item_YouTube =
            arrayListOf(
                arrayListOf("Numbers Game", "CiFyTc1SwPw"),// I take the link from solution.
                arrayListOf("Calculator", "ZbZFMDk69IA"),
                arrayListOf("Guess the Phrase", "DU1qMhyKv8g")
            )

        YouTube_Player_View = findViewById(R.id.YouTube_Player_View)
        Grid_View = findViewById(R.id.Grid_View)

        //check internet connection and network state
        var Connectivity_Manager = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: NetworkInfo? = Connectivity_Manager.activeNetworkInfo

        if(!activeNetwork?.isConnectedOrConnecting!! == true){
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Internet Connection Not Found!!")
                .setPositiveButton("RETRY!!"){_, _ ->
                    Connectivity_Manager = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                    val activeNetwork: NetworkInfo? = Connectivity_Manager.activeNetworkInfo
                }
                .show()
        }

        YouTube_Player_View.addYouTubePlayerListener(object: AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                super.onReady(youTubePlayer)

                YouTube_Player = youTubePlayer
                YouTube_Player.loadVideo(item_YouTube[current][1], time)
                Grid_View.adapter = GridAdapter(this@MainActivity, YouTube_Player, item_YouTube)
            }
        })
    }

    //  to track device rotation
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (newConfig.orientation === Configuration.ORIENTATION_LANDSCAPE) {
            YouTube_Player_View.enterFullScreen()
        } else if (newConfig.orientation === Configuration.ORIENTATION_PORTRAIT) {
            YouTube_Player_View.exitFullScreen()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putInt("current Video", current)
        outState.putFloat("time Stamp", time)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        current = savedInstanceState.getInt("current Video", 0)
        time = savedInstanceState.getFloat("time Stamp", 0f)
    }

}