package com.example.youtubebonusapp_laila

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer

class GridAdapter (val context: Context, private val player: YouTubePlayer, val messages: ArrayList<ArrayList<String>>):
    BaseAdapter(){

    private var layout_Inflater: LayoutInflater? = null
    lateinit var Button_Video: Button

    override fun getCount()= messages.size

    override fun getItem(position: Int) = messages[position]

    override fun getItemId(position: Int)= position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        var convertView = convertView

        if (layout_Inflater==null)
        {
            layout_Inflater= context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        }
        if (convertView == null)
        {
            convertView = layout_Inflater!!.inflate(R.layout.item_row,null)

        }
        if (convertView != null) {
            Button_Video = convertView.findViewById(R.id.Button_Video)
            Button_Video.text = messages[position][0]
            Button_Video.setOnClickListener{
                player.loadVideo(messages[position][1], 0f)
            }
        }
        return convertView!!
    }
}