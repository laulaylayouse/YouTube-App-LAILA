package com.example.youtubeapp_core_laila

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import kotlinx.android.synthetic.main.item_row.view.*

class RVAdapter (val context: YouTubePlayer, val messages: ArrayList<ArrayList<String>>):
    RecyclerView.Adapter<RVAdapter.MessageViewHolder>() {

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

        val Button_Video: Button = itemView.Button_Video
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.item_row,
            parent,
            false
        )
        return MessageViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {

        holder.Button_Video.text = messages[position][0]
        holder.Button_Video.setOnClickListener {
            context.loadVideo(messages[position][1], 0f)
        }
    }

    override fun getItemCount() = messages.size
}